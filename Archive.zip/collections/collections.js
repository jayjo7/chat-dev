Menu = new Mongo.Collection('menu');

Orders = new Mongo.Collection('orders');

Cart = new Mongo.Collection('cart');

CartItems = new Mongo.Collection('cartitems');

//Counter maps to 'Order Number'
Counters = new Mongo.Collection('counters');

Content = new  Mongo.Collection('Content');

Settings = new  Mongo.Collection('Settings');

OrderedItems = new Mongo.Collection('ordereditems');

PaymentInfo = new Mongo.Collection('paymentInfo');
